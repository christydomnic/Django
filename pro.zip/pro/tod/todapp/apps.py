from django.apps import AppConfig


class TodappConfig(AppConfig):
    name = 'todapp'
